
multiply = function( multiplier1, multiplier2){
	return multiplier1*multiplier2;	
}